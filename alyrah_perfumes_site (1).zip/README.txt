ALYRAH PERFUMES - loja virtual inicial

1. Abra index.html no navegador para visualizar.
2. Substitua os produtos, preços, telefone e Instagram pelos dados reais.
3. Antes de vender, configure um gateway de pagamento (Pix/cartão), frete, domínio, políticas da loja e dados da empresa.
4. As imagens dos produtos devem ser substituídas por fotos que você tenha autorização para usar.
5. Os preços e produtos do exemplo são apenas demonstrativos.

O checkout incluído é uma demonstração visual; ele ainda não processa pagamentos reais.
